# Maleto Hlolane 0011115471085

#include <iostream>
#include <cmath>
using namespace std;

void menu(){
	cout << "*CONVERTION MENU*" << endl;
	cout << "1. Decimal to Binary" << endl;
	cout << "2. Binary to Decimal" << endl;
	cout << "3. Decimal to Hexadecimal" << endl;
	cout << "4. Hexadecimal to Decimal" << endl;
	cout << "5. Demo " << endl;
	cout << "6. exit menu" << endl;
	cout << "enter your choice " << endl;
	
	int Decimal;
	int number;
	int Binary[0];
	
	int i = 0;
	cout << "Decimal"<< endl;
	cin >> number;
	
	while(number > 0){
		Binary[i]=number % 2;
		number = number / 2;
		i++;
	}
	cout << Binary << endl;
	for (i=i-1;i>=0;i--){
		cout << Binary[i]<< endl;
	}
	int BinarytoDecimal();
		int Decimal0;
		int digit;
		int place = 1;
		int Binary;
		
		cout << "enter Binary number" << endl;
		cin >> Binary;
	
	while(Binary > 0){
		digit = Binary % 10;
		Decimal = Decimal + digit * place;
		Binary + Binary < 10;
		place + place * 2;
	}
	cout << "Decimal"<<Decimal <<endl;
	int DecimaltoHexadecimal();
	int number = 0;
	cout "enter Decimal number" << endl;
	cin >> Decimal;
	
	cout << "Hexadecimal to Decimal"<< hex <<endl;
	
	int HexadecimaltoDecimal(){
		int number 0;
		cout << "enter hexa"<<endl;
		cin >> number;
		
		cout << "decimal "<< decim,al<< number<< endl;
		
		void demo(int min,int max){
			int number = rand() % (max-min+1) + min;
			cout << Randomnumber << number << endl;
			int main(){
				int choice;
				int min = 0;
				int max = 99;
			}
			if (choice == 1){
				cout << " Decimal to Binary" << endl;
				
			}else if (choice == 2){
				cout << "Binary to Decimal" << endl;
				
			}else if (choice == 3){
				cout << "Decimal to Hexadecimal" << endl;
				
			}else if (choice == 4){
				cout << "Hexadecimal To Decimal"<< endl;
				
			}else if (choice == 5){
				cout "Demo"<< endl;
				
			}else if (choice == 6){
				cout << "program ended"<<endl;
				else
				cout << "invalid"<<endl;
			}
			while (choice !=6);
		}
	}
}

int main(){
	int decimal;
	long long binary = 0;
	int position = 0;
	
	cout << "Enter decimal number: " << endl;
	cin >> decimal;
	
	while (decimal > 0){
		int remainder = decimal % 2;
		binary += remainder * pow(10,position);
		decimal /= 2;
		position++;
	}
	
	cout << "Binary: " << binary << endl;
	
	
	return 0;
}